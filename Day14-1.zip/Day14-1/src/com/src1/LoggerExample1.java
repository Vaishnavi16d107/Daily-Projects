/**
 * @author vaishnavi
 * @date 22/11/2020
 * LoggerExample1 class is for performing logging
 */
package com.src1;
import java.util.Scanner;
import org.apache.log4j.Logger;
public class LoggerExample1 {
    static Logger log=Logger.getLogger(LoggerExample1.class);//getting Logger object from static method getLogger method for class LoggerExample1 class
	public static void main(String[] args) {
		 int number;//declaring a number
		 Scanner sc=new Scanner(System.in);
		 log.info("enter number");//info level is used for collecting information that supports logger class
         System.out.println("enter number");
         log.info("getting number from user");
         number=sc.nextInt();//accepting number from user
         log.debug("debugging loop");//debug level also supports logger class by collecting information
         for(int i=0;i<number;i++)
         {
        	 System.out.print(i+" ");//printing values upto number
         }
         
         
	}
	

}
