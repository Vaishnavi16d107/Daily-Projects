package com.src;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

public class StudentDao {
	
	@Autowired
    JdbcTemplate jdbctemplate;
	public JdbcTemplate getJdbctemplate() {
		return jdbctemplate;
	}

	public void setJdbctemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate = jdbctemplate;
	}
	
	public int insertFunction(StudentClass s)
	{   
		
		String query="insert into student values("+s.getSid()+",'"+s.getSname()+"','"+s.getSgender()+"')";
		
		return jdbctemplate.update(query);
	}
	
	
	public List<StudentClass> displayFunction(StudentClass s)
	{
		return jdbctemplate.query("select * from student",new ResultSetExtractor<List<StudentClass>>(){  
		    @Override  
		     public List<StudentClass> extractData(ResultSet rs) throws SQLException,DataAccessException {  
		      
		        List<StudentClass> list=new ArrayList<StudentClass>();  
		        while(rs.next()){  
			        StudentClass s=new StudentClass();
			        s.setSid(rs.getInt(1));
			        s.setSname(rs.getString(2));
			        s.setSgender(rs.getString(3));
			        list.add(s);  
		        }  
		        return list;  
		    }

		    
		   
		
		    });  
	
	}
	
	public int deleteFunction(StudentClass s)
	{   
		
		String query="delete from student where sid="+s.getSid();
		
		return jdbctemplate.update(query);
	}
	
	

	public int updateFunction(StudentClass s)
	{   
		s.setSgender("male");
		String query="update student set gender='"+s.getSgender()+"' where sid="+s.getSid();
		
		return jdbctemplate.update(query);
	}

}
