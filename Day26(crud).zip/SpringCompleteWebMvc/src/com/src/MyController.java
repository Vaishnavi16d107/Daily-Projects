package com.src;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {
	
	@Autowired
	StudentDao sd;
	StudentClass s=new StudentClass();
	@RequestMapping("/register")
	public String validate(@RequestParam("id")String id,@RequestParam("name")String name,@RequestParam("gender")String gender,Model m)
	{   
		//StudentClass s=new StudentClass();
		s.setSid(Integer.parseInt(id));
		s.setSname(name);
		s.setSgender(gender);
		
		//StudentDao sd=new StudentDao();
		
		int i=sd.insertFunction(s);
		
		String msg=i+"got inserted";
		
		m.addAttribute("message", msg);
		
		return "index";
		
		
	   
	}
	
	@RequestMapping("/retrieve")
	public String display(Model m)
	{  
	   //StudentClass s=new StudentClass();
       List<StudentClass> li=sd.displayFunction(s);
		
		m.addAttribute("li", li);
		
		return "display";
		
		
	   
	}
	
	 @RequestMapping("/delete")
		public String deleteFunct(@RequestParam("sid")String sid, Model m)
		{
			
			s.setSid(Integer.valueOf(sid));
			
			sd.deleteFunction(s);
			
			List<StudentClass> l=sd.displayFunction(s);
			m.addAttribute("li",l);
			
			return "display";
		}
      
	 @RequestMapping("/update")
		public String updateFunct(@RequestParam("sid")String sid, Model m)
		{
			
			s.setSid(Integer.valueOf(sid));
			
			sd.updateFunction(s);
			
			List<StudentClass> l=sd.displayFunction(s);
			m.addAttribute("li",l);
			
			return "display";
		}
}
