package com.src;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertClass {
	//this class inserts data into database
	public static void insertFunction(DataSourceClass dsc,StudentClass sc)
	{	
		Connection con=null;
		try {
			Class.forName(dsc.getDriverClass());//loading driver class
			con = DriverManager.getConnection(dsc.getUrl(),dsc.getUser(),dsc.getPassword());//getting connectiion
			Statement st=con.createStatement();
			int i=st.executeUpdate("insert into student values("+sc.getSid()+",'"+sc.getName()+"','"+sc.getGender()+"')");//performing insertion
	        if(i>0)
	        {
	        	System.out.println("data inserted");
	        }
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

		
		
		
}
	
	
	
	


