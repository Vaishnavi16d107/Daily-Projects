package com.src;

import java.sql.SQLException;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
	
		ApplicationContext ac=new AnnotationConfigApplicationContext(ApplicationContextConfig.class);//applicationContext container gets details from annotaion config class
		DataSourceClass dsc=(DataSourceClass) ac.getBean("mysql");//creating object for Datasource class
		Scanner sc=new Scanner(System.in);
		System.out.println("1)insert");//printing menu option
		System.out.println("2)delete");
		System.out.println("3)update");
		System.out.println("4)retrieve");
		System.out.println("Enter your Choice");
		int ch=sc.nextInt();//accepting choice from user
		switch(ch)
		{
			case 1:
			{
				StudentClass c=new StudentClass();
				System.out.println("Enter student id");//accepting details from user
				c.setSid(sc.nextInt());
				System.out.println("Enter student name");
				c.setName(sc.next());
				System.out.println("Enter student gender");
				c.setGender(sc.next());
				InsertClass.insertFunction(dsc, c);
			}
			break;
			case 2:
			{
				System.out.println("Enter student id to be deleted");//accepting id to be deleted
				int id=sc.nextInt();
				DeleteClass.deleteFunction(dsc, id);
			
			}
			break;
			case 3:
			{
				System.out.println("Enter student name");//accepting name to be updated
				String name=sc.next();
				updateClass.updateFunction(dsc, name);
				
			}
			break;
			case 4:
			{
				System.out.println("Enter student id");//accepting id to be displayed
				int id=sc.nextInt();
				RetriveClass.dispalyFunction(dsc, id);
				
			}
			break;
			default:
				System.out.println("Invalid");
				break;
		}
		
	}

	}


