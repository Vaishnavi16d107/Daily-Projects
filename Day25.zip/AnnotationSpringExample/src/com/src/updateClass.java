package com.src;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class updateClass {
	
	//this class updates record in database
	public static void updateFunction(DataSourceClass dsc,String name) throws SQLException, ClassNotFoundException
	{   
		Class.forName(dsc.getDriverClass());//loading driver class
		Connection con=DriverManager.getConnection(dsc.getUrl(),dsc.getUser(),dsc.getPassword());//getting connection
		Statement st=con.createStatement();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter gender to be corrected");
		String gender=sc.next();//getting attribute to be updated
		int j=st.executeUpdate("update student set gender='"+gender+"' where sname='"+name+"'");//performing updation
		 if(j>0)
	        {
	        	System.out.println("data updated");
	        }
	}

}
