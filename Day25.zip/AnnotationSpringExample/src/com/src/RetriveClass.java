package com.src;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RetriveClass {
	
	public static void dispalyFunction(DataSourceClass dsc,int id) throws SQLException, ClassNotFoundException
	{ 
		Class.forName(dsc.getDriverClass());
		Connection con=DriverManager.getConnection(dsc.getUrl(),dsc.getUser(),dsc.getPassword());
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from student where sid="+id);

		while(rs.next())
		{
			System.out.println(rs.getInt("sid")+" "+rs.getString("sname")+" "+rs.getString("gender"));

		}
	}

}
