package com.src;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DeleteClass {
	
	//this class deletes the record from database
	public static void deleteFunction(DataSourceClass ds,int id) throws SQLException, ClassNotFoundException
	{   
		Class.forName(ds.getDriverClass());//loading driver class
		Connection con=DriverManager.getConnection(ds.getUrl(),ds.getUser(),ds.getPassword());//getting connection
		Statement st=con.createStatement();
		int i=st.executeUpdate("delete from student where sid='"+id+"'");//performing deletion of specified id
		  if(i>0)
	        {
	        	System.out.println("data deleted");
	        }
	}

}
