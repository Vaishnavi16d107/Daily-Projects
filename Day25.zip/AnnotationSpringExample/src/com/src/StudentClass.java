package com.src;

public class StudentClass {
	private int sid;//declaring properties of student
	private String name;
	private String gender;
	
	//setter and getter to initialize properties
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	

}
