package com.src;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationContextConfig {
	//this class configuration bean class to create object of DataSource Class
	String driver;
	String url;
	String user;
	String password;
	
	@Bean(name="mysql")
	public DataSourceClass getDataSource()
	{  
		driver="com.mysql.cj.jdbc.Driver";
		url="jdbc:mysql://localhost:3306/vaishnavidb";
	    user="root";
	    password="Vaish59501#";
	    return new DataSourceClass(driver,url,user,password);//returning object of DataSource Class
	}
	
	

}
