package com.src;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

public class EmpDao {
	
   Scanner sc=new Scanner(System.in);
   JdbcTemplate jdbctemplate;//creating jdbctemplate object that takes care of database connectivity
   
	public JdbcTemplate getJdbctemplate() {
		return jdbctemplate;
	}

	public void setJdbctemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate = jdbctemplate;
	}
	
	
	
	
	public int insertFunction(EmployeeClass e)
	{   
		//insert method to insert data into database
		String query="insert into employee values("+e.getId()+",'"+e.getName()+"',"+e.getSal()+",'"+e.getDob()+"',"+e.getYears()+")";
		
		return jdbctemplate.update(query);
	}
	
	
	public int deleteFunction(EmployeeClass e)
	{   
		//delete method to delete data from database of specified id
		System.out.println("enter id to be deleted");
		int id=sc.nextInt();
        String query="delete from employee where Eid="+id+"";
		
		return jdbctemplate.update(query);
	}
	
	
	public int updateFunction(EmployeeClass e)
	{  
		//update method to update data of specified id in database
		System.out.println("enter id to be updated");
		int id=sc.nextInt();
		System.out.println("enter salary to be updated");
		double sal=sc.nextDouble();
        String query="update employee set esal="+sal+" where Eid="+id+"";
		
		return jdbctemplate.update(query);
	}
    
	
	public List<EmployeeClass> displayFunction(){  
		//this method to display records using resultset extractor into a list
		 return jdbctemplate.query("select * from employee",new ResultSetExtractor<List<EmployeeClass>>(){  
		    @Override  
		     public List<EmployeeClass> extractData(ResultSet rs) throws SQLException,DataAccessException {  
		      
		        List<EmployeeClass> list=new ArrayList<EmployeeClass>();  
		        while(rs.next()){  
			        EmployeeClass e=new EmployeeClass();
			        e.setId(rs.getInt(1));  
			        e.setName(rs.getString(2));  
			        e.setSal(rs.getDouble(3));  
			        e.setDob(rs.getString(4));
			        e.setYears(rs.getInt(5));
			        list.add(e);  
		        }  
		        return list;  
		    }

		
		    });  
		  }
	
	
	
	
	
}
