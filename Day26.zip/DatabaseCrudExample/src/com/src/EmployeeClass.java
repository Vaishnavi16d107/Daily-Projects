package com.src;

public class EmployeeClass {
    private int id;//declaring properties for employee
	private String name;
	private double sal;
	private String dob;
	private int years;
	
	//setter and getter methods to initialize properties
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public int getYears() {
		return years;
	}
	public void setYears(int years) {
		this.years = years;
	}
	
	//toString() method to display all properties
	@Override
	public String toString() {
		return "EmployeeClass [id=" + id + ", name=" + name + ", sal=" + sal + ", dob=" + dob + ", years=" + years
				+ "]";
	}
	
	
}
