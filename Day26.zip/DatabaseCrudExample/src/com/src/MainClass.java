package com.src;

import java.util.Iterator;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");//application context container reads details from xml file
		EmployeeClass e=(EmployeeClass) context.getBean("emp");//creating object for employee class
		
		EmpDao ed=(EmpDao) context.getBean("empdao");
		
		int i=ed.insertFunction(e);//returns no of rows inserted
		if(i>0)
		{
			System.out.println("data inserted");
		}
		
		int j=ed.deleteFunction(e);//returns no of rows deleted
		if(j>0)
		{
			System.out.println("data deleted");
		}
		
		int k=ed.updateFunction(e);//returns the row affected
		if(k>0)
		{
			System.out.println("data updated");
		}
		
	   List<EmployeeClass> li=ed.displayFunction();
	   
	   Iterator<EmployeeClass> it=li.iterator();
	   
	   while(it.hasNext())
	   {
		   System.out.println(it.next());//displaying list containing records of employee
	   }
		

	}

}
