package com.src;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationcontext.xml");//applicationcontext container reads details from xml file
	    RectangleShape r=(RectangleShape) context.getBean("shape1");//creating rectangle shape object
		r.drawShape();
		
		SquareShape s=(SquareShape) context.getBean("shape2");//creating square shape object
		s.drawShape();
		
		CicleShape c=(CicleShape) context.getBean("shape3");//creating circle shape object
		c.drawShape();

	}

}
