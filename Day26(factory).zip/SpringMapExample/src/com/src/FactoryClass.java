package com.src;

public class FactoryClass {
	
	//this class contains all methods that supplies objects for each implemented class of shapes
	public static Shapes getShape()
	{ 
		return new RectangleShape();
	}
	
	public static Shapes getShape1()
	{ 
		return new SquareShape();
	}
	
	public static Shapes getShape2()
	{ 
		return new CicleShape();
	}
	


}
