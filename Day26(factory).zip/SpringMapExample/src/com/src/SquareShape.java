package com.src;

public class SquareShape implements Shapes{
    
	//this class implements shapes interface to draw square shape
	@Override
	public void drawShape() {
		System.out.println("draw Square");
		
	}
	

}
