package com.src;

public interface Shapes {
	
    public void drawShape();

}
