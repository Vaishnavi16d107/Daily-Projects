package com.src;

public class CicleShape implements Shapes{
    
	//this class implements shapes interface to draw Circle shape
	@Override
	public void drawShape() {
		
		System.out.println("draw circle");
		
	}
	


}
