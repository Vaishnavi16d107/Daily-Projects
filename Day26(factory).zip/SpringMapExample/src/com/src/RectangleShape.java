package com.src;

public class RectangleShape implements Shapes{
    
	//this class implements shapes interface to draw rectangle shape
	@Override
	public void drawShape() {
		System.out.println("drawing rectangle");
		
	}

}


